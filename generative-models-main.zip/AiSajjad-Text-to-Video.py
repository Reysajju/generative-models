from transformers import pipeline, GPT2LMHeadModel, GPT2Tokenizer

class GPT2TextGenerator:
    def __init__(self, model_path):
        self.model = GPT2LMHeadModel.from_pretrained(model_path)
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_path)

    def generate_text(self, prompt):
        inputs = self.tokenizer(prompt, return_tensors="pt")
        outputs = self.model(**inputs)
        generated_text = self.tokenizer.decode(outputs["logits"][0], skip_special_tokens=True)
        return generated_text

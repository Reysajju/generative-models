from .dataset import StableDataModuleFromConfig

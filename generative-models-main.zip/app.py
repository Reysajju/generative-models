from flask import Flask, request, jsonify
from your_model_inference_module import GPT2TextGenerator  # Adjusted import

app = Flask(__name__)
model_inference = GPT2TextGenerator("your_model_directory")  # Adjusted class instantiation

@app.route('/generate_text', methods=['POST'])
def generate_text():
    data = request.get_json()
    
    if 'prompt' not in data:
        return jsonify({"error": "Please provide a 'prompt' in the request body"}), 400

    prompt = data['prompt']
    generated_text = model_inference.generate_text(prompt)
    return jsonify({"generated_text": generated_text})

if __name__ == '__main__':
    app.run(port=5000)

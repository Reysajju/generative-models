inference_api:
  - url: "https://huggingface.co/ReySajju742/AiSajjad-Text-to-Video"
    method: "POST"
    payload:
      prompt: "alligator taking bath in coffee cup"
